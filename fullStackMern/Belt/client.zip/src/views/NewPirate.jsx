import React from 'react'
import Form from '../components/Form'

const NewPirate = () => {
  return (
    <div>
        <h1>Add Pirate</h1>
        <Form/>
    </div>
  )
}

export default NewPirate